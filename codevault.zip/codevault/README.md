# { CodeVault } 🔐

> **A personal DSA Problem Tracker** — Track every problem you solve, tag it, write notes, and visualize your progress.

Built as a Final Year Project (B.Tech CSE, 2026) using **Spring Boot**, **MySQL**, **Thymeleaf**, and **Spring Security**.

---

## 📸 Screenshots

> Dashboard · Problem List · Add Problem · Problem Detail

*(Add screenshots to `/screenshots` folder after running the project)*

---

## 🛠️ Tech Stack

| Layer       | Technology                        |
|-------------|-----------------------------------|
| Backend     | Spring Boot 3.2, Spring MVC       |
| ORM         | Spring Data JPA + Hibernate       |
| Database    | MySQL 8.0                         |
| Frontend    | Thymeleaf (Server-Side Rendering) |
| Security    | Spring Security (BCrypt)          |
| Build Tool  | Maven                             |
| Java        | Java 17                           |

---

## ✨ Features

- 🔐 **User Authentication** — Register & Login with BCrypt-hashed passwords
- ➕ **Add/Edit/Delete Problems** — Full CRUD with validation
- 🏷️ **Smart Tagging** — Tag by topic (Array, DP, Tree...), platform (LeetCode, GFG...), difficulty
- 📊 **Progress Dashboard** — Visual stats: Solved / Attempted / Pending / Revisit
- ⭐ **Star Problems** — Mark important problems for quick access
- 🔍 **Search & Filter** — Search by title, filter by status/difficulty/topic
- 📝 **Personal Notes** — Write your approach, time & space complexity per problem
- 🔒 **Secure** — Each user sees only their own data

---

## 🚀 Getting Started

### Prerequisites
- Java 17+
- MySQL 8.0+
- Maven 3.8+

### 1. Clone the Repository
```bash
git clone https://github.com/YOUR_USERNAME/codevault.git
cd codevault
```

### 2. Create MySQL Database
```sql
CREATE DATABASE codevault_db;
```

### 3. Configure Database
Edit `src/main/resources/application.properties`:
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/codevault_db?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=YOUR_PASSWORD
```

### 4. Run the Application
```bash
mvn spring-boot:run
```

### 5. Open in Browser
```
http://localhost:8080
```

---

## 📁 Project Structure

```
src/main/java/com/codevault/
├── CodeVaultApplication.java       # Entry point
├── config/
│   └── SecurityConfig.java         # Spring Security setup
├── controller/
│   ├── HomeController.java
│   ├── AuthController.java
│   ├── DashboardController.java
│   └── ProblemController.java
├── dto/
│   ├── ProblemDto.java
│   └── RegisterDto.java
├── model/
│   ├── User.java
│   └── Problem.java                # EASY/MEDIUM/HARD, SOLVED/ATTEMPTED/PENDING/REVISIT
├── repository/
│   ├── UserRepository.java
│   └── ProblemRepository.java      # Custom JPQL queries
└── service/
    ├── UserService.java
    └── ProblemService.java

src/main/resources/
├── templates/
│   ├── index.html                  # Landing page
│   ├── auth/login.html
│   ├── auth/register.html
│   ├── dashboard/dashboard.html
│   └── problems/ (list, form, detail)
└── static/css/style.css            # Dark hacker theme
```

---

## 🗄️ Database Schema

**users** — `id, username, email, password, created_at`

**problems** — `id, title, problem_url, difficulty, status, topic_tag, platform, notes, time_complexity, space_complexity, starred, attempt_count, created_at, updated_at, user_id`

---

## 🎯 Key Concepts Demonstrated

- **MVC Architecture** — Controllers → Services → Repositories
- **Spring Data JPA** — Custom JPQL queries, entity relationships (`@OneToMany`, `@ManyToOne`)
- **Spring Security** — Password hashing, session-based auth, route protection
- **Bean Validation** — `@Valid`, `@NotBlank`, `@Email`, `BindingResult`
- **Thymeleaf** — Template engine with Spring Security integration
- **DTO Pattern** — Separating form data from entity models

---

## 👤 Author

**[Your Name]** — B.Tech CSE, 2026 Batch  
[GitHub](https://github.com/YOUR_USERNAME) · [LinkedIn](https://linkedin.com/in/YOUR_PROFILE)

---

## 📄 License

MIT License — feel free to use and modify.
