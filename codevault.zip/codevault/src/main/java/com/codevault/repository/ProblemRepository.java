package com.codevault.repository;

import com.codevault.model.Problem;
import com.codevault.model.Problem.Difficulty;
import com.codevault.model.Problem.Status;
import com.codevault.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProblemRepository extends JpaRepository<Problem, Long> {

    // All problems of a user
    List<Problem> findByUserOrderByCreatedAtDesc(User user);

    // Filter by status
    List<Problem> findByUserAndStatusOrderByCreatedAtDesc(User user, Status status);

    // Filter by difficulty
    List<Problem> findByUserAndDifficultyOrderByCreatedAtDesc(User user, Difficulty difficulty);

    // Filter by topic tag
    List<Problem> findByUserAndTopicTagContainingIgnoreCaseOrderByCreatedAtDesc(User user, String topicTag);

    // Starred problems
    List<Problem> findByUserAndStarredTrueOrderByCreatedAtDesc(User user);

    // Count by status
    long countByUserAndStatus(User user, Status status);

    // Count by difficulty
    long countByUserAndDifficulty(User user, Difficulty difficulty);

    // Search by title
    List<Problem> findByUserAndTitleContainingIgnoreCaseOrderByCreatedAtDesc(User user, String title);

    // Distinct topics for a user
    @Query("SELECT DISTINCT p.topicTag FROM Problem p WHERE p.user = :user AND p.topicTag IS NOT NULL")
    List<String> findDistinctTopicsByUser(@Param("user") User user);

    // Total count for a user
    long countByUser(User user);
}
