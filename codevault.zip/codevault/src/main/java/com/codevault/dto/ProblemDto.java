package com.codevault.dto;

import com.codevault.model.Problem.Difficulty;
import com.codevault.model.Problem.Status;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ProblemDto {

    private Long id;

    @NotBlank(message = "Problem title is required")
    private String title;

    private String problemUrl;

    @NotNull(message = "Difficulty is required")
    private Difficulty difficulty;

    @NotNull(message = "Status is required")
    private Status status;

    private String topicTag;

    private String platform;

    private String notes;

    private String timeComplexity;

    private String spaceComplexity;

    private boolean starred;
}
