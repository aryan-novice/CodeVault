package com.codevault.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "problems")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Problem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(nullable = false)
    private String title;

    @Column(name = "problem_url")
    private String problemUrl;   // LeetCode / GFG / Codeforces link

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Difficulty difficulty;  // EASY, MEDIUM, HARD

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status;           // SOLVED, ATTEMPTED, PENDING, REVISIT

    @Column(name = "topic_tag")
    private String topicTag;     // Array, Tree, DP, Graph, etc.

    @Column(name = "platform")
    private String platform;     // LeetCode, GFG, Codeforces, HackerRank

    @Column(columnDefinition = "TEXT")
    private String notes;        // Personal notes / approach

    @Column(name = "time_complexity")
    private String timeComplexity;  // O(n), O(n log n), etc.

    @Column(name = "space_complexity")
    private String spaceComplexity;

    @Column(name = "is_starred")
    private boolean starred;     // Mark important problems

    @Column(name = "attempt_count")
    private int attemptCount;    // How many times tried

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        if (this.attemptCount == 0) this.attemptCount = 1;
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    public enum Difficulty {
        EASY, MEDIUM, HARD
    }

    public enum Status {
        SOLVED, ATTEMPTED, PENDING, REVISIT
    }
}
