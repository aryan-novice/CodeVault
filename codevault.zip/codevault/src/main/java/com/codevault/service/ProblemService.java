package com.codevault.service;

import com.codevault.dto.ProblemDto;
import com.codevault.model.Problem;
import com.codevault.model.Problem.Difficulty;
import com.codevault.model.Problem.Status;
import com.codevault.model.User;
import com.codevault.repository.ProblemRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class ProblemService {

    private final ProblemRepository problemRepository;

    // ---- CRUD ----

    public Problem addProblem(ProblemDto dto, User user) {
        Problem problem = Problem.builder()
                .title(dto.getTitle())
                .problemUrl(dto.getProblemUrl())
                .difficulty(dto.getDifficulty())
                .status(dto.getStatus())
                .topicTag(dto.getTopicTag())
                .platform(dto.getPlatform())
                .notes(dto.getNotes())
                .timeComplexity(dto.getTimeComplexity())
                .spaceComplexity(dto.getSpaceComplexity())
                .starred(dto.isStarred())
                .user(user)
                .build();
        return problemRepository.save(problem);
    }

    public Problem updateProblem(Long id, ProblemDto dto, User user) {
        Problem problem = getProblemByIdAndUser(id, user);
        problem.setTitle(dto.getTitle());
        problem.setProblemUrl(dto.getProblemUrl());
        problem.setDifficulty(dto.getDifficulty());
        problem.setStatus(dto.getStatus());
        problem.setTopicTag(dto.getTopicTag());
        problem.setPlatform(dto.getPlatform());
        problem.setNotes(dto.getNotes());
        problem.setTimeComplexity(dto.getTimeComplexity());
        problem.setSpaceComplexity(dto.getSpaceComplexity());
        problem.setStarred(dto.isStarred());
        return problemRepository.save(problem);
    }

    public void deleteProblem(Long id, User user) {
        Problem problem = getProblemByIdAndUser(id, user);
        problemRepository.delete(problem);
    }

    public Problem getProblemByIdAndUser(Long id, User user) {
        return problemRepository.findById(id)
                .filter(p -> p.getUser().getId().equals(user.getId()))
                .orElseThrow(() -> new RuntimeException("Problem not found or access denied"));
    }

    // ---- Listing & Filtering ----

    public List<Problem> getAllProblems(User user) {
        return problemRepository.findByUserOrderByCreatedAtDesc(user);
    }

    public List<Problem> filterByStatus(User user, Status status) {
        return problemRepository.findByUserAndStatusOrderByCreatedAtDesc(user, status);
    }

    public List<Problem> filterByDifficulty(User user, Difficulty difficulty) {
        return problemRepository.findByUserAndDifficultyOrderByCreatedAtDesc(user, difficulty);
    }

    public List<Problem> searchByTitle(User user, String keyword) {
        return problemRepository.findByUserAndTitleContainingIgnoreCaseOrderByCreatedAtDesc(user, keyword);
    }

    public List<Problem> filterByTopic(User user, String topic) {
        return problemRepository.findByUserAndTopicTagContainingIgnoreCaseOrderByCreatedAtDesc(user, topic);
    }

    public List<Problem> getStarredProblems(User user) {
        return problemRepository.findByUserAndStarredTrueOrderByCreatedAtDesc(user);
    }

    // ---- Dashboard Stats ----

    public Map<String, Long> getStatusStats(User user) {
        Map<String, Long> stats = new HashMap<>();
        stats.put("SOLVED",    problemRepository.countByUserAndStatus(user, Status.SOLVED));
        stats.put("ATTEMPTED", problemRepository.countByUserAndStatus(user, Status.ATTEMPTED));
        stats.put("PENDING",   problemRepository.countByUserAndStatus(user, Status.PENDING));
        stats.put("REVISIT",   problemRepository.countByUserAndStatus(user, Status.REVISIT));
        return stats;
    }

    public Map<String, Long> getDifficultyStats(User user) {
        Map<String, Long> stats = new HashMap<>();
        stats.put("EASY",   problemRepository.countByUserAndDifficulty(user, Difficulty.EASY));
        stats.put("MEDIUM", problemRepository.countByUserAndDifficulty(user, Difficulty.MEDIUM));
        stats.put("HARD",   problemRepository.countByUserAndDifficulty(user, Difficulty.HARD));
        return stats;
    }

    public long getTotalCount(User user) {
        return problemRepository.countByUser(user);
    }

    public List<String> getDistinctTopics(User user) {
        return problemRepository.findDistinctTopicsByUser(user);
    }

    // Convert Problem -> DTO (for edit pre-fill)
    public ProblemDto toDto(Problem p) {
        ProblemDto dto = new ProblemDto();
        dto.setId(p.getId());
        dto.setTitle(p.getTitle());
        dto.setProblemUrl(p.getProblemUrl());
        dto.setDifficulty(p.getDifficulty());
        dto.setStatus(p.getStatus());
        dto.setTopicTag(p.getTopicTag());
        dto.setPlatform(p.getPlatform());
        dto.setNotes(p.getNotes());
        dto.setTimeComplexity(p.getTimeComplexity());
        dto.setSpaceComplexity(p.getSpaceComplexity());
        dto.setStarred(p.isStarred());
        return dto;
    }
}
