package com.codevault.controller;

import com.codevault.dto.ProblemDto;
import com.codevault.model.Problem;
import com.codevault.model.Problem.Difficulty;
import com.codevault.model.Problem.Status;
import com.codevault.model.User;
import com.codevault.service.ProblemService;
import com.codevault.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/problems")
@RequiredArgsConstructor
public class ProblemController {

    private final ProblemService problemService;
    private final UserService userService;

    // ---- List / Filter ----
    @GetMapping
    public String listProblems(@AuthenticationPrincipal UserDetails userDetails,
                               @RequestParam(required = false) String status,
                               @RequestParam(required = false) String difficulty,
                               @RequestParam(required = false) String topic,
                               @RequestParam(required = false) String search,
                               @RequestParam(required = false) String starred,
                               Model model) {

        User user = userService.findByUsername(userDetails.getUsername());
        List<Problem> problems;

        if (search != null && !search.isBlank()) {
            problems = problemService.searchByTitle(user, search);
        } else if (status != null && !status.isBlank()) {
            problems = problemService.filterByStatus(user, Status.valueOf(status));
        } else if (difficulty != null && !difficulty.isBlank()) {
            problems = problemService.filterByDifficulty(user, Difficulty.valueOf(difficulty));
        } else if (topic != null && !topic.isBlank()) {
            problems = problemService.filterByTopic(user, topic);
        } else if ("true".equals(starred)) {
            problems = problemService.getStarredProblems(user);
        } else {
            problems = problemService.getAllProblems(user);
        }

        model.addAttribute("problems", problems);
        model.addAttribute("topics", problemService.getDistinctTopics(user));
        model.addAttribute("total", problemService.getTotalCount(user));
        return "problems/list";
    }

    // ---- Add Form ----
    @GetMapping("/add")
    public String addForm(Model model) {
        model.addAttribute("problemDto", new ProblemDto());
        model.addAttribute("mode", "add");
        return "problems/form";
    }

    @PostMapping("/add")
    public String addProblem(@AuthenticationPrincipal UserDetails userDetails,
                             @Valid @ModelAttribute ProblemDto dto,
                             BindingResult result,
                             Model model,
                             RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            model.addAttribute("mode", "add");
            return "problems/form";
        }
        User user = userService.findByUsername(userDetails.getUsername());
        problemService.addProblem(dto, user);
        redirectAttributes.addFlashAttribute("successMsg", "Problem added successfully!");
        return "redirect:/problems";
    }

    // ---- Edit Form ----
    @GetMapping("/edit/{id}")
    public String editForm(@AuthenticationPrincipal UserDetails userDetails,
                           @PathVariable Long id, Model model) {
        User user = userService.findByUsername(userDetails.getUsername());
        Problem problem = problemService.getProblemByIdAndUser(id, user);
        model.addAttribute("problemDto", problemService.toDto(problem));
        model.addAttribute("mode", "edit");
        return "problems/form";
    }

    @PostMapping("/edit/{id}")
    public String updateProblem(@AuthenticationPrincipal UserDetails userDetails,
                                @PathVariable Long id,
                                @Valid @ModelAttribute ProblemDto dto,
                                BindingResult result,
                                Model model,
                                RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            model.addAttribute("mode", "edit");
            return "problems/form";
        }
        User user = userService.findByUsername(userDetails.getUsername());
        problemService.updateProblem(id, dto, user);
        redirectAttributes.addFlashAttribute("successMsg", "Problem updated!");
        return "redirect:/problems";
    }

    // ---- View Detail ----
    @GetMapping("/view/{id}")
    public String viewProblem(@AuthenticationPrincipal UserDetails userDetails,
                              @PathVariable Long id, Model model) {
        User user = userService.findByUsername(userDetails.getUsername());
        Problem problem = problemService.getProblemByIdAndUser(id, user);
        model.addAttribute("problem", problem);
        return "problems/detail";
    }

    // ---- Delete ----
    @PostMapping("/delete/{id}")
    public String deleteProblem(@AuthenticationPrincipal UserDetails userDetails,
                                @PathVariable Long id,
                                RedirectAttributes redirectAttributes) {
        User user = userService.findByUsername(userDetails.getUsername());
        problemService.deleteProblem(id, user);
        redirectAttributes.addFlashAttribute("successMsg", "Problem deleted.");
        return "redirect:/problems";
    }
}
