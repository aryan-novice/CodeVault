package com.codevault.controller;

import com.codevault.model.User;
import com.codevault.service.ProblemService;
import com.codevault.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@RequiredArgsConstructor
public class DashboardController {

    private final ProblemService problemService;
    private final UserService userService;

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.findByUsername(userDetails.getUsername());

        model.addAttribute("user", user);
        model.addAttribute("total",          problemService.getTotalCount(user));
        model.addAttribute("statusStats",    problemService.getStatusStats(user));
        model.addAttribute("difficultyStats",problemService.getDifficultyStats(user));
        model.addAttribute("recentProblems", problemService.getAllProblems(user)
                .stream().limit(5).toList());
        model.addAttribute("starredProblems",problemService.getStarredProblems(user));
        model.addAttribute("topics",         problemService.getDistinctTopics(user));

        return "dashboard/dashboard";
    }
}
